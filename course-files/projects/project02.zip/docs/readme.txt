To generate pdocs:

https://pdoc.dev/

pdoc apis/yelp.py -o docs --html
pdoc apis/spotify.py -o docs --html
pdoc apis/twilio.py -o docs --html
pdoc apis/authentication.py -o docs --html
