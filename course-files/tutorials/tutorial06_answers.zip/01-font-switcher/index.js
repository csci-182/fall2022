const makeBigger = (ev) => {
    document.querySelector('.content').style.fontSize = '3em';
    document.querySelector('h1').style.fontSize = '3em';
};

const makeSmaller = (ev) => {
    document.querySelector('.content').style.fontSize = '1.4em';
    document.querySelector('h1').style.fontSize = '2em';
};
