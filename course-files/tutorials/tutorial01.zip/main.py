#############
# Problem 1 #
#############
print()
print ('#' * 13)
print ('# Problem 1 #')
print ('#' * 13)
print()

# your answer here...



#############
# Problem 2 #
#############
# Pick from from: https://www.asciiart.eu/animals/
print()
print ('#' * 13)
print ('# Problem 2 #')
print ('#' * 13)
print()

# your answer here...