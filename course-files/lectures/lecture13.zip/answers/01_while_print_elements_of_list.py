names = ['Larry', 'Curly', 'Moe', 'Seamus']

# write a while loop that prints every item in the names list:

i = 0
while i < len(names):
    print(i, names[i])
    i += 1
