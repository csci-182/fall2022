numbers = [
    76, 76, 76, 72, 76, 79, 67, 72, 67, 64, 69, 71,
    70, 69, 67, 76, 79, 81, 77, 79, 76, 72, 74, 71
]

# Challenge: 
# 1. play every third note in the numbers list any way you can think of.
# 2. play every third note in the numbers list using a range function.
