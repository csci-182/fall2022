# Challenge: write a program that counts all of the negative, positive, 
# and zero values in the numbers list (below):

numbers = [5, 2, 5, 0, -2, -4, -7, 4, 7, 8]