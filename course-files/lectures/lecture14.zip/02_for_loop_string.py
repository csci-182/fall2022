message = 'hello world!'

# Challenge: use a for loop to print all of the characters 
# in the string stored in the variable message

