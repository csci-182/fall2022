# ---------------------------------------
# 2. functions with a required parameter
# ---------------------------------------
# function definition:
def say_hello(name: str):
    print('Hello there,', name, end='! ')
    print('How are you this morning?')

# function calls:
say_hello('Varun')
say_hello('Grace')
say_hello('Charlie')
say_hello('Jazmin')

# result = say_hello('Jazmin')
# print('No return value:', result)


