avatar_position = (100, 100)

def move_avatar(direction, units):
    global avatar_position
    # your code here...

move_avatar('up', 10)
print('The new avatar position is:', avatar_position)
move_avatar('down', 15)
print('The new avatar position is:', avatar_position)
move_avatar('left', 2)
print('The new avatar position is:', avatar_position)
move_avatar('right', 3)
print('The new avatar position is:', avatar_position)
