const btsMembers = [
    {
        nickname: 'RM',
        name: { 'english': 'Kim Nam Joon', 'korean': '김남준' },
        roles: ['leader', 'rapper']
    },
    {
        nickname: 'Jin',
        name: { 'english': 'Kim Seok Jin', 'korean': '김석진' },
        roles: ['visual', 'vocalist']
    },
    {
        nickname: 'Suga',
        name: { 'english': 'Min Yoon Gi', 'korean': '민윤기' },
        roles: ['rapper']
    },
    {
        nickname: 'J-Hope',
        name: { 'english': 'Jung Ho Seok', 'korean': '정호석' },
        roles: ['rapper', 'dancer', 'vocalist']
    },
    {
        nickname: 'Jimin',
        name: { 'english': 'Park Ji Min', 'korean': '박지민' },
        roles: ['vocalist', 'dancer']
    },
    {
        nickname: 'V',
        name: { 'english': 'Kim Tae Hyung', 'korean': '김태형' },
        roles: ['dancer', 'vocalist', 'visual']
    },
    {
        nickname: 'Jungkook',
        name: { 'english': 'Jeon Jeong-guk', 'korean': '전정국' },
        roles: ['vocalist', 'dancer']
    }
]